configuration CreateADDNS
{
   param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,
        [Parameter(Mandatory)]
        [String]$Netbios,
        [Parameter(Mandatory)]
        [String]$MachineName,
        [Parameter(Mandatory)]
        [PSCredential]$AdminCreds
    )
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement
    Import-DscResource -ModuleName cNtfsAccessControl
    Import-DscResource -Name MSFT_xSmbShare
    [PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)
    [String]$sharePath = 'C:\awingu\Users'

    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        WindowsFeature DNS
        {
            Ensure = 'Present'
            Name = 'DNS'
        }

        WindowsFeature DNSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-DNS-Server'
            DependsOn = '[WindowsFeature]DNS'
        }

        WindowsFeature ADDSInstall
        {
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
            DependsOn = '[WindowsFeature]DNSTools'

        }

        WindowsFeature ADDSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-AD-Tools'
            IncludeAllSubFeature = $true
            DependsOn = '[WindowsFeature]ADDSInstall'
        }

        xADDomain AddDomain
        {
            DomainName = $DomainName
            DomainNetBIOSName = $Netbios
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn = '[WindowsFeature]ADDSTools'
        }

        xComputer NewName
        {
            Name = $MachineName
            Credential = $DomainCreds
            DomainName = $DomainName
            DependsOn = '[xADDomain]AddDomain'
        }

        File AwinguUsersFolder {
            Ensure = 'Present'
            Type = 'Directory'
            DestinationPath = $sharePath
            DependsOn = '[xComputer]NewName'
        }

        cNtfsPermissionEntry FilePermissionChange {
            Ensure = 'Present'
            Principal = 'Domain Users'
            Path = $sharePath
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'ReadPermissions', 'CreateFiles', 'WriteData', 'AppendData', 'CreateDirectories'
                    Inheritance = 'ThisFolderOnly'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]AwinguUsersFolder'
        }

        xSmbShare CreateShare
        {
            Ensure = 'Present'
            Name = 'Users'
            Path = $sharePath
            ChangeAccess = 'Domain Users'
            Description = 'This will be the home drive for awingu users'
            DependsOn =  '[File]AwinguUsersFolder'
        }
    }
}
