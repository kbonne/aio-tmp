#!/usr/bin/env python3
import argparse
import random
import datetime
import logging
import requests
import json
import re
import os
import copy
import sys

from six.moves.urllib.parse import urlparse
from awingu_api_helpers import AwinguHelper

logger = logging.getLogger('configure_awingu')
logger.setLevel(logging.DEBUG)

fh = logging.FileHandler('configure_awingu.log', mode='w')
fh.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
fh.setLevel(logging.DEBUG)
logger.addHandler(fh)

ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
ch.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
logger.addHandler(ch)

READY_TIMEOUT = 120
KEEP_REPOSERVER_VERSION = re.compile(r'v?[0-9]+\.[0-9]+\.[0-9]+'
                                     r'(\.[0-9]+(-.*)?)?')
URI_ID_REX = re.compile(r'/api/\w*/(?P<id>\d+)/')
THIS_DIR = os.path.dirname(os.path.abspath(__file__))


class AwinguConfiguration(object):
    def __init__(self, params=None):
        self._parse_args(
            [i
             for key, value in params.items()
             for i in ['--' + key] + value.split(' ')
             if i != '']
            if params is not None else sys.argv[1:])
        self.session = requests.Session()
        self.helper = AwinguHelper(logger, self.session,
                                   self.params.frontend_ip,
                                   https=self.params.https)

    def _parse_args(self, args):
        parser = argparse.ArgumentParser(
            description='Configure an awingu appliance')
        parser.add_argument('--extra_config', default='{}',
                            type=lambda x: json.loads(x),
                            help='Overwrite the config with this values')
        parser.add_argument(
            '--domains', required=True, nargs='+',
            help='Space separated list of the domains that  should be '
                 'configured')
        parser.add_argument(
            '--default_domain', required=True,
            help='Sets both the global config and the default domain')
        parser.add_argument('--version', help='Version to deploy; mandatory '
                            'if you want to invalidate the repo')
        parser.add_argument('--vm_name', required=True,
                            help='Name of your appliance')
        parser.add_argument('--frontend_ip', required=True,
                            help='IP of your appliance (proxy service)')
        parser.add_argument(
            '--import_appserver_whitelist', nargs='+',
            help='App servers hostnames to configure from the selected domain')
        parser.add_argument(
            '--appserver_template',
            help='App server template to use for the import of the appservers')
        parser.add_argument('--import_appservers', help='Import app servers?',
                            action='store_true')
        parser.add_argument('--mock_appliance', action='store_true',
                            help='Put the appliance in mocked mode?')
        parser.add_argument('--invalidate_repo',
                            help='Invalidate repo?',
                            default='if_testing_version',
                            choices=['yes', 'no', 'if_testing_version'])
        parser.add_argument('--username', default='admin',
                            help='Admin username in the appliance')
        parser.add_argument(
            '--password', default='rooter1234',
            help='Password for the admin username in the appliance')
        parser.add_argument(
            '--https', action='store_true', help='Configure behind https?')
        parser.add_argument('--write_api_token', action='store_true',
                            help='Write the api token to the filesystem?')
        parser.add_argument('--randomize_authentication', action='store_true',
                            help='Randomize the use of the API token')

        self.params = parser.parse_args(args)

    def _update_dict(self, original, updates):
        for key, value in updates.items():
            if isinstance(value, dict) and isinstance(original.get(key), dict):
                self._update_dict(original[key], value)
            else:
                original[key] = value

    def get_component_config(self, component, domain):
        empty = False
        component_config = {}
        config_path = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                                   domain,
                                                   component + '.json'))

        if os.path.exists(config_path):
            with open(config_path, 'r') as fp:
                logger.debug('Configuration file found for %s', component)
                try:
                    component_config = json.load(fp)
                except:
                    logger.info('Something went wrong while parsing %s',
                                config_path)
                    logger.info('Please check the JSON file for errors')
                    raise
        else:
            logger.debug('No configuration found for %s', component)
            empty = True

        if self.params.extra_config:
            updates = self.params.extra_config.get(
                domain, {}).get(component, {})

            if updates:
                if isinstance(component_config, dict):
                    self._update_dict(component_config, updates)
                else:
                    component_config = updates

        logger.debug('{} configuration: {}'.format(component,
                                                   str(component_config)))
        return component_config if not empty else None

    def import_appservers_from_ad(self, appserver_template, domain_name):
        domains = self.helper.api_call(
            'get', '{}?name={}'.format(
                self.api_uris['domains'], domain_name)).json()
        domains = domains['results'] if 'results' in domains else domains

        appservers = self.helper.api_call(
            'get', domains[0]['query_ldap_appservers']).json()

        final_config = []
        for appserver in appservers:
            if (any([re.match(wlist, appserver['host_name'])
                     for wlist in self.params.import_appserver_whitelist])):
                appserver_config = copy.deepcopy(appserver_template)
                appserver_config['host'] = appserver['host_name']
                appserver_config['name'] = appserver['name']
                appserver_config['description'] = appserver['name']
                final_config.append(appserver_config)

        return final_config

    def configure_smcapi_component(self, uri, component_config):
        current_config = self.helper.api_call('get', uri).json()
        new_config = copy.deepcopy(current_config)
        new_config.update(component_config)
        if new_config != current_config:
            new_config.pop('uri')
            self.helper.api_call('put', uri, data=json.dumps(new_config))

    def invalidate_reposerver(self):
        logger.info('Invalidating reposerver URL')
        uri = self.helper.api_call(
            'get', self.api_uris['configuration']).json()['results'][0]['uri']
        self.helper.api_call(
            'patch', uri, data={'repo_url': 'http://notbuild.awingu.com'})

    @staticmethod
    def _read_certificate(component_config, field):
        certificate_path = os.path.join(
            THIS_DIR, 'certs', component_config[field])
        with open(certificate_path) as fp:
            component_config[field] = fp.read()

    def configure_certificates(self, component_config):
        for certificate in component_config:
            AwinguConfiguration._read_certificate(certificate, 'certificate')
            AwinguConfiguration._read_certificate(certificate, 'private_key')
            self.helper.api_call(
                'post', self.api_uris['certificates'], data=certificate)

    def configure_contacts(self, component_config):
        configuration = self.helper.api_call(
            'get', self.api_uris['configuration']).json()['results'][0]
        for key, contact in component_config.items():
            self.helper.api_call('patch', configuration[key], data=contact)

    def configure_domains(self, component_config):
        if 'idp_certificate' in component_config:
            AwinguConfiguration._read_certificate(component_config,
                                                  'idp_certificate')
        if 'idp_private_key' in component_config:
            AwinguConfiguration._read_certificate(component_config,
                                                  'idp_private_key')

        hostheaders_config = component_config.pop('host_headers', [])

        domain = self.helper.api_call(
            'post', self.api_uris['domains'],
            data=json.dumps(component_config),
            headers={'Accept': 'application/json'}).json()
        login_footer = [
            ('Hostname', self.params.vm_name),
            ('Configured',
             datetime.datetime.now().isoformat(' ').rpartition(':')[0] +
             ' UTC'),
            ('Domain', domain['name']),
        ]
        self.helper.api_call(
            'patch', domain['branding'],
            data={'login_footer': '<br>\n'.join('{}: {}'.format(k, v)
                                                for k, v in login_footer)})

        for hostheader in hostheaders_config:
            self.helper.api_call('post', self.api_uris['hostheaders'],
                                 data=json.dumps({
                                     'name': hostheader,
                                     'domain': domain['uri']
                                 }),
                                 headers={'Accept': 'application/json'})
        self.helper.wait_for_smc(max_errors=2, timeout=120,
                                 action='domain creation')

    def configure_apps(self, component_config, domain_name):
        domain = self.helper.api_call(
            'get', '{}?name={}'.format(
                self.api_uris['domains'], domain_name)).json()['results'][0]

        for app in component_config:
            icon = self.add_icon(app['icon'], domain)
            app['domain'] = domain['uri']
            app['icon'] = icon['uri']

            self.helper.api_call(
                'post', self.api_uris['apps'], data=app).json()
            if app.get('source_host_header', '') != '':
                self.helper.wait_for_smc(max_errors=2, timeout=120,
                                         action='reverse proxy app')

    def add_icon(self, file_name, domain):
        icon_path = os.path.join(THIS_DIR, 'icons', file_name)
        return self.helper.upload_in_smc(
            domain['create_app_icon'], icon_path, domain_uri=domain['uri'])

    def configure_branding(self, component_config, domain_name):
        domain = self.helper.api_call(
            'get', '{}?name={}'.format(
                self.api_uris['domains'], domain_name)).json()['results'][0]
        branding_uri = domain['branding']
        branding = self.helper.api_call('get', branding_uri).json()

        custom_images = {key: loc for key, loc in component_config.items()
                         if key.startswith('custom_')}
        for key, loc in custom_images.items():
            if key == 'custom_favicon':
                self.helper.upload_in_smc(branding['generate_favicon'], loc)
                del component_config[key]
            elif not branding[key]:
                # First time
                branding_image = self.helper.upload_in_smc(
                    domain['create_branding_image'], loc,
                    domain_uri=domain['uri'])
                component_config[key] = branding_image['uri']
            else:
                # Replace existing image
                self.helper.upload_in_smc(branding[key]['update'], loc)
                del component_config[key]

        if component_config:
            self.helper.api_call('patch', branding_uri, data=component_config)

    def configure_features(self, component_config, domain_name):
        domain = self.helper.api_call(
            'get', '{}?name={}'.format(
                self.api_uris['domains'], domain_name)).json()['results'][0]
        features = self.helper.api_call(
            'get', domain['features']).json()['results']
        for feature in [f for f in features if f['name'] in component_config]:
            self.helper.api_call(
                'patch', feature['uri'],
                data={'labels': component_config[feature['name']]})

    def configure_service_providers(self, component_config, domain_name):
        domain = self.helper.api_call(
            'get', '{}?name={}'.format(
                self.api_uris['domains'], domain_name)).json()['results'][0]
        service_providers = self.helper.api_call(
            'get', domain['service_providers']).json()['results']
        for provider_config in component_config:
            service_provider = next(t for t in service_providers
                                    if t['name'] == provider_config['name'])
            self.helper.api_call(
                'patch', service_provider['uri'], data=provider_config)

    def configure_twofactor_providers(self, component_config, domain_name):
        domain = self.helper.api_call(
            'get', '{}?name={}'.format(
                self.api_uris['domains'], domain_name)).json()['results'][0]
        twofactor_providers = self.helper.api_call(
            'get', domain['twofactor_providers']).json()['results']
        twofactor_provider = next(t for t in twofactor_providers
                                  if t['key'] == component_config['key'])
        self.helper.api_call(
            'patch', domain['uri'],
            data={'twofactor': twofactor_provider['uri']})
        if 'config' in component_config:
            self.helper.api_call(
                'patch', twofactor_provider['uri'],
                data={'config': component_config['config']})

    def configure_for_domain(self, component_name, component_config,
                             domain_name):
        domain = self.helper.api_call(
            'get', '{}?name={}'.format(
                self.api_uris['domains'], domain_name)).json()['results'][0]

        for component in component_config:
            component['domain'] = domain['uri']
            self.helper.api_call('post', self.api_uris[component_name],
                                 data=json.dumps(component))

    def configure_component(self, component, component_config, domain_name):
        logger.info('Configuring {} for {}'.format(component, domain_name))
        uri = self.api_uris.get(component)

        if component == 'domains':
            self.configure_domains(component_config)
        elif component == 'app-servers' and \
                self.params.import_appservers:
            import_appservers_config = self.import_appservers_from_ad(
                json.loads(self.params.appserver_template), domain_name)
            self.configure_for_domain(component, component_config, domain_name)
            self.configure_for_domain(component, import_appservers_config,
                                      domain_name)
        elif component == 'configuration':
            uri = self.helper.api_call('get', uri).json()['results'][0]['uri']
            self.helper.api_call('patch', uri, data=component_config)
        elif component == 'certificates':
            self.configure_certificates(component_config)
        elif component == 'contacts':
            self.configure_contacts(component_config)
        elif component == 'apps':
            self.configure_apps(component_config, domain_name)
        elif component == 'branding':
            self.configure_branding(component_config, domain_name)
        elif component == 'features':
            self.configure_features(component_config, domain_name)
        elif component == 'service-providers':
            self.configure_service_providers(component_config, domain_name)
        elif component == 'twofactor-providers':
            self.configure_twofactor_providers(component_config, domain_name)
        elif re.match(r'/api/v\d+/', uri) is not None:
            self.configure_for_domain(component, component_config, domain_name)
        else:
            raise NotImplementedError

    def configure_via_api(self):
        self.helper.login(self.params.username, self.params.password,
                          timeout=READY_TIMEOUT)

        if self.params.randomize_authentication:
            authenticate_with_token = random.choice([True, False])
        else:
            authenticate_with_token = True

        if authenticate_with_token:
            token = self.helper.api_call(
                'post', '/api/v2/sessions/generate-token/',
                data={'password': self.params.password}).json()['token']
            self.helper.api_call('delete', '/api/v2/sessions/current/')
            self.helper.set_api_token(token)

            if self.params.write_api_token:
                api_token_path = os.path.abspath(os.path.join(
                    os.path.dirname(__file__), 'api_token'))
                with open(api_token_path, 'w') as fp:
                    fp.write(token)

        self.api_uris = {
            key: urlparse(uri).path
            for key, uri in self.helper.api_call(
                'get', '/api/v2').json().items()
        }

        priority_components = ['domains', 'user-groups', 'labels',
                               'categories', 'media-types', 'app-servers']
        components = priority_components + [c for c in self.api_uris
                                            if c not in priority_components]

        global_config = self.get_component_config('global',
                                                  self.params.default_domain)
        default_domain_name = global_config['domains']['name']

        global_components = [c for c in priority_components
                             if c in global_config.keys()] + \
                            [c for c in global_config
                             if c not in priority_components]

        logger.info('Configuring global components {}'.format(
            ' '.join(global_components)))
        for component in global_components:
            component_config = global_config[component]
            self.configure_component(component, component_config,
                                     default_domain_name)

        for domain in self.params.domains:
            domain_config = self.get_component_config('global',
                                                      domain)['domains']
            domain_name = domain_config['name']

            for component in components:
                if component == 'domains':
                    if domain != self.params.default_domain:
                        self.configure_component(
                            'domains', domain_config, domain_name)
                else:
                    component_config = self.get_component_config(component,
                                                                 domain)
                    # Note: global configs won't be overwritten again, because
                    # we don't have network.json etc.
                    if component_config is not None:
                        self.configure_component(component, component_config,
                                                 domain_name)

        apply_changes_needed = self.helper.is_apply_changes_needed()

        if self.params.invalidate_repo == 'yes' or \
                (self.params.invalidate_repo == 'if_testing_version' and
                 not KEEP_REPOSERVER_VERSION.match(self.params.version)):
            self.invalidate_reposerver()

        logger.info('Waiting for unfinished partial updates')
        self.helper.wait_for_smc(max_errors=0, timeout=360,
                                 action='partial update')

        if self.params.mock_appliance:
            import fabric
            from install_awingu import fabfile
            key_filename = os.path.expanduser('~/.ssh/intervention_dev.pem')
            with fabric.context_managers.settings(
                    host_string=self.helper.ip, user='root',
                    disable_known_hosts=True,
                    key_filename=key_filename):
                fabfile.write_custom_sls('mocked: true')
            apply_changes_needed = True

        if apply_changes_needed:
            self.helper.apply_changes()

        if authenticate_with_token:
            session = requests.Session()
            another_helper = AwinguHelper(
                logger, session, self.params.frontend_ip,
                https=self.params.https)
            another_helper.login(self.params.username, self.params.password)
            another_helper.api_call(
                'post', '/api/v2/sessions/disable-token/',
                data={'password': self.params.password})
            another_helper.api_call('delete', '/api/v2/sessions/current/')
        else:
            self.helper.api_call('delete', '/api/v2/sessions/current/')

if __name__ == "__main__":
    config_helper = AwinguConfiguration()
    config_helper.configure_via_api()
