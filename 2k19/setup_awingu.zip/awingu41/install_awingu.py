#!/usr/bin/env python3
import requests
import time
import os
import logging
import argparse
import json
import sys

from awingu_api_helpers import AwinguHelper


logger = logging.getLogger('install_awingu')
logger.setLevel(logging.DEBUG)

fh = logging.FileHandler('install_awingu.log', mode='w')
fh.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
logger.addHandler(fh)

ch = logging.StreamHandler()
ch.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
logger.addHandler(ch)

READY_TIMEOUT = 180
MAX_INSTALLATION_ERRORS = 10
INSTALLATION_TIMEOUT = 60 * 30


def json_argument(arg):
    return json.loads(arg)


class AwinguInstaller(object):
    def __init__(self, params=None):
        self._parse_args(
            [i
             for key, value in params.items()
             for i in ['--' + key] + value.split(' ')
             if i != '']
            if params is not None else sys.argv[1:])
        self.config = self._load_config()

    def _parse_args(self, args):
        parser = argparse.ArgumentParser(
            description='Install awingu through the API')
        parser.add_argument('--extra_config', default='{}', type=json_argument,
                            help='Overwrite the config with this values')
        parser.add_argument(
            '--domain', required=True,
            help='Configure DNS and NTP for this domain')
        parser.add_argument('--database', default='',
                            help='External database uris, '
                                 'omit for internal database')
        parser.add_argument('--version',
                            help='Version to deploy')
        parser.add_argument('--repo_url', required=True,
                            help='Repo url to use for the packages')
        parser.add_argument('--vm_name', required=True,
                            help='Name of your appliance')
        parser.add_argument('--frontend_ip', required=True,
                            help='IP of your appliance')
        parser.add_argument('--custom_sls', default={}, type=json_argument,
                            help='Content of the custom.sls file if provided '
                                 'as a JSON document')
        parser.add_argument('--skip_dev_keys', action='store_true',
                            help='Use this when you want to use the real '
                                 'license validator and the real intervention '
                                 'key.')
        parser.add_argument('--domain_config_path',
                            help='Directory to import from the domain config',
                            default='../configure_awingu')
        parser.add_argument('--install_timeout',
                            default=INSTALLATION_TIMEOUT, type=int,
                            help='Timeout to wait for install to finish')

        self.params = parser.parse_args(args)

    def _load_config(self):
        basename = os.path.abspath(os.path.dirname(__file__))

        global_config_fn = os.path.join(basename, 'config.json')
        with open(global_config_fn) as fp:
            global_config = json.load(fp)

        config_basename = os.path.abspath(os.path.join(
            os.path.dirname(__file__), self.params.domain_config_path))
        domain_config_fn = os.path.join(
            config_basename, self.params.domain, 'global.json')
        with open(domain_config_fn) as fp:
            domain_config = json.load(fp)
        global_config.update(domain_config['configuration'])

        global_config.update(self.params.extra_config)

        return global_config

    def _build_install_config(self):
        is_external_database = bool(self.params.database)
        database = self.params.database if is_external_database else ''
        installer_config = {
            'config': {
                'eula': {
                    'accepted': True,
                },
                'environment': {
                    'management_user': {
                        'username': self.config['username'],
                        'password': self.config['password'],
                        'confirmed_password': self.config['password'],
                    },
                },
                'network': {
                    'repo': self.params.repo_url,
                    'ntp': self.config['ntp_server'],
                    'dns': self.config['dns_ip'],
                },
                'features': {
                    'common': {
                        'external_database': is_external_database,
                    }
                },
                'appliances': [{
                    'hostname': self.params.vm_name,
                    'ip_address': self.params.frontend_ip,
                    'is_backend': 'backend' in self.config['services'],
                    'is_database': 'database' in self.config['services'],
                    'is_frontend': 'frontend' in self.config['services'],
                }],
                'database': database
            }
        }

        if self.params.version:
            installer_config['version_number'] = self.params.version

        return installer_config

    def patch_appliance(self):
        import fabfile
        import fabric.context_managers

        key_filename = os.path.expanduser('~/.ssh/appliance.pem')
        with fabric.context_managers.settings(
                host_string=self.params.frontend_ip, user='root',
                disable_known_hosts=True,
                key_filename=key_filename):
            if self.params.custom_sls:
                fabfile.write_custom_sls(self.params.custom_sls)
            if not self.params.skip_dev_keys:
                fabfile.add_license_verification_key()

    def install_via_api(self):
        start_time = time.time()
        logger.info('Waiting for max. {} seconds '
                    'for installer API to be available'.format(READY_TIMEOUT))
        while time.time() - start_time <= READY_TIMEOUT:
            try:
                requests.get(url='http://{}:8080'.format(
                    self.params.frontend_ip))
            except requests.exceptions.ConnectionError:
                time.sleep(5)
            else:
                break
        else:
            raise RuntimeError(
                'Installer API not available after {} seconds'.format(
                    READY_TIMEOUT))

        if self.params.custom_sls or not self.params.skip_dev_keys:
            self.patch_appliance()

        install_config = self._build_install_config()
        logger.info('Sending install config to {}:\n{}'.format(
            self.params.frontend_ip,
            json.dumps(install_config, indent=4, sort_keys=True,
                       separators=(',', ': '))))

        time.sleep(5)

        session = requests.Session()
        ip = '{}:8080'.format(self.params.frontend_ip)
        awingu_helper = AwinguHelper(logger, session, ip)
        awingu_helper.install(config=install_config,
                              timeout=self.params.install_timeout)


if __name__ == '__main__':
    installer = AwinguInstaller()
    installer.install_via_api()
