import io
import json
import logging
import os
import pprint
import re
import tempfile
import time
from datetime import datetime, timedelta

import requests
from six.moves.urllib.parse import urlparse, unquote

MIME_TYPES = {
    'png': 'image/png',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'ico': 'image/x-icon',
    'svg': 'image/svg+xml',
}


class FileNotFound(Exception):
    pass


class InvalidFileType(Exception):
    pass


class TimeoutError(Exception):
    pass


class PreviewError(Exception):
    pass


class RdpGatewayError(Exception):
    pass


class AwinguHelper(object):
    READY_URI_RE = re.compile(r"url: '/ready/(?P<location>.+)'")

    def __init__(self, logger, session, ip, https=False, relogin=True):
        self.logger = logger
        self.session = session
        self.username = self.password = self.domain = None
        self.ip = ip
        self.protocol = 'https' if https else 'http'
        self.relogin = relogin

    def _log_headers(self, headers, logger):
        logger('Headers:')
        for line in pprint.pformat(dict(headers), width=1).splitlines():
            logger(u'{}{}'.format(9 * ' ', line))

    def _log_data(self, data, logger):
        if data:
            logger('Data:')
            try:
                data_dict = json.loads(data)
                for line in pprint.pformat(data_dict, width=1).splitlines():
                    logger(u'{}{}'.format(6 * ' ', line))
            except Exception:
                logger(u'{}{}'.format(6 * ' ', data))
        else:
            return

    def _log_request_response(self, response, logger):
        request = response.request
        logger('{}REQUEST{}'.format(40 * '-', 40 * '-'))
        logger('{} to {}'.format(request.method, request.url))
        headers_to_log = dict()
        headers_to_log.update(self.session.headers)
        headers_to_log.update(request.headers if request.headers else {})
        self._log_headers(headers_to_log, logger)
        if 'Content-Type' in request.headers and \
                'multipart' not in request.headers['Content-Type']:
            self._log_data(request.body, logger)

        logger('{}RESPONSE STATUS {} {}'.format(
            (40 * '-'), response.status_code, (40 * '-')))
        self._log_headers(response.headers, logger)
        self._log_data(response.text, logger)
        logger('\n{}\n'.format(80 * '='))

        if response.history:
            for h in response.history:
                if 'location' in h.headers:
                    logger('{}REDIRECT TO {}{}'.format(
                        (40 * '-'), h.headers['location'], (40 * '-')))

    def _api_call(self, request_type, url, data, headers, log=False, **kwargs):
        call = getattr(self.session, request_type.lower())

        if headers is None:
            headers = {}
        if 'files' not in kwargs and 'Content-Type' not in headers:
            headers['Content-Type'] = 'application/json'
        if self.protocol == 'https' and \
                'referer' not in map(lambda x: x.lower(), headers.keys()):
            headers['Referer'] = '{}://{}'.format(self.protocol, self.ip)

        response = call(url, data=data, headers=headers, **kwargs)

        if log:
            self._log_request_response(response, self.logger.debug)

        return response

    def api_call(self, request_type, endpoint, data=None,
                 headers=None, raise_for_status=True, relogin=None, **kwargs):
        if relogin is None:
            relogin = self.relogin
        if endpoint.startswith('http'):
            url = endpoint
        else:
            url = u'{}://{}{}'.format(self.protocol, self.ip, endpoint)
        if isinstance(data, (list, dict)):
            data = json.dumps(data)
        response = self._api_call(request_type, url, data, headers, **kwargs)
        self.logger.info(u'{} to {} returned {}'.format(
            request_type.upper(), url, response.status_code))

        if relogin and response.status_code == 401 and \
                self.username is not None and \
                self.password is not None and not \
                (request_type == 'POST' and endpoint == '/api/v2/sessions/'):
            self.logger.info(u'User logged out, signing in again...')
            self.login(self.username, self.password, self.domain)
            response = self._api_call(request_type, url, data, headers,
                                      **kwargs)

        # Retry if we get a 429 Client Error: too many requests
        if response.status_code == 429:
            self.logger.warning(
                u'Due to HTTP error {} ({}), we will wait 1 minute and '
                'retry'.format(response.status_code, response.reason))
            time.sleep(60)

            response = self._api_call(request_type, url, data, headers,
                                      **kwargs)

        if raise_for_status:
            try:
                response.raise_for_status()
            except Exception:
                self._log_request_response(response, self.logger.error)
                raise

        return response

    def upload_in_smc(self, endpoint, path, domain_uri=None, headers=None,
                      raise_for_status=True, **kwargs):
        """
        Path can be URL or path on disk
        """
        file_name = os.path.basename(path)
        content_type = MIME_TYPES[file_name.rpartition('.')[-1].lower()]
        content = {'domain': (None, domain_uri)} if domain_uri else {}
        try:
            if path.startswith('http'):
                r = requests.get(path, stream=True)
                file_object = io.BytesIO(r.content)
            else:
                file_object = open(path, 'rb')
            content['file'] = (file_name, file_object, content_type)
            response = self.api_call(
                'POST', endpoint, files=content, headers=headers,
                raise_for_status=raise_for_status, **kwargs)
        finally:
            file_object.close()
        return response.json()

    def _search_dict_for_uris(self, src):
        result = []
        for key, value in src.items():
            if isinstance(value, dict):
                result += self._search_dict_for_uris(value)
            if 'uri' in key.lower():
                result.append({key: value})

        return result

    def wait_for_smc(self, max_errors, timeout, action):
        unfinished_updates_uri = self._get_uri_from_configuration(
            'unfinished_updates')
        errors = 0
        start_time = time.time()
        ignore_msg = u'Ignore error during getting status of {}: {}'
        failed_update = None
        while time.time() - start_time <= timeout:
            if errors and errors >= max_errors:
                raise RuntimeError(
                    u'Getting status of {} failed {} times'.format(action,
                                                                   errors))
            time.sleep(5)
            try:
                r = self.api_call('get', unfinished_updates_uri,
                                  raise_for_status=False, log=False)
            except requests.exceptions.ConnectionError as e:
                # This can happen during network restart of the instance
                self.logger.warning(ignore_msg.format(action, e))
                errors += 1
                continue

            try:
                r.raise_for_status()
            except requests.exceptions.HTTPError as e:
                self.logger.warning(ignore_msg.format(action, e))
                errors += 1
                continue

            updates = r.json()['results']

            if len(updates) == 0:
                self.logger.info('All updates finished successfully.')
                return

            for update in updates:
                success_statuses = ['IN_PROGRESS', 'QUEUED', 'SUCCEEDED']
                if update['status'] not in success_statuses:
                    failed_update = update
                    break

            if failed_update is not None:
                break
        else:
            raise RuntimeError(
                u'{} via API was not finished after {} minutes'.format(
                    action.capitalize(), timeout / 60))

        assert failed_update is not None

        if failed_update['status'] == 'FAILED':
            assert failed_update['status'] == 'FAILED'
            r = self.api_call('get', failed_update['outputs'])

            log_messages = []
            for object in r.json()['results']:
                log_message = '*' * 79 + '\n'
                log_message += object['host'] + '\n'
                log_message += '*' * 79 + '\n'
                log_message += object['value']
                log_messages.append(log_message)
            self.logger.error(u'The {} failed with following log:\n{}'.format(
                action, '\n\n'.join(log_messages)))

            raise RuntimeError(u'The {} failed'.format(action))
        else:
            raise RuntimeError(u'The {} finished with status {}'.format(
                               action, failed_update["status"]))

    def _login(self, username, password, domain=None, https=None):
        base_url = u'{}://{}'.format(self.protocol, self.ip)
        self.api_call('get', '', log=False)

        creds = {
            'privacy_policy_accepted': True,
            'password': password,
            'username': username,
        }
        if domain is not None:
            creds['domain'] = domain
        headers = {'Content-Type': 'application/json', 'referer': base_url}
        r = self.api_call('post', '/api/v2/sessions/', log=False,
                          data=json.dumps(creds), headers=headers)

        self.username = username
        self.password = password
        self.domain = domain

        self.session.headers.update({
            'Accept': '*/*',
            'X-csrftoken': self.session.cookies.get('csrftoken')
        })

        return r

    def set_api_token(self, token):
        self.session.headers['Authorization'] = 'Token %s' % token

    def login(self, username, password, domain=None, timeout=None):
        """
        Login to Awingu with given username and password.
        If timeout is provided, it will try to login for the provided timeout,
        otherwise it will fail immediately.
        """
        self.username = username
        self.password = password
        if not timeout:
            return self._login(username, password, domain)
        else:
            start_time = time.time()
            self.logger.info('Waiting for max. {} seconds to be able to '
                             'sign-in'.format(timeout))
            while time.time() - start_time <= timeout:
                try:
                    return self._login(username, password, domain)
                except requests.exceptions.HTTPError as e:
                    self.logger.warning(
                        'Ignore error during sign-in: {}'.format(e))
                    time.sleep(10)
                else:
                    break
            else:
                raise RuntimeError(
                    "Still can't sign in after {} seconds".format(timeout))

    def install(self, config, timeout=900):
        self.logger.info('Installing Awingu')
        self._update('installation', data=config, is_installation=True,
                     timeout=timeout, wait_for_other_updates=0)

    def apply_changes(self, wait_for_other_updates=120):
        self.logger.info('Applying changes')
        appliances = self.api_call('get', '/api/v2/appliances').json()
        timeout = (5 + 20 * len(appliances['results'])) * 60
        self._update(
            'configuration', timeout=timeout,
            wait_for_other_updates=wait_for_other_updates)

    def upgrade(self, version, wait_for_other_updates=120):
        appliances = self.api_call('get', '/api/v2/appliances').json()
        timeout = (5 + 70 * len(appliances['results'])) * 60
        max_errors = 150 * len(appliances['results'])

        current_version = self.api_call(
            'get', '/api/v2/versions/current/').json()
        versions = self.api_call(
            'get', current_version['allowed_upgrade_versions']).json()
        upgrade_to_version = [v for v in versions if v['number'] == version][0]
        data = {
            'version': upgrade_to_version['uri'],
            'eula_accepted': True
        }

        # Upgrade to 3.6 has long downtime due to PostgreSQL upgrade
        self._update(
            'upgrade', data=data, timeout=timeout, max_errors=max_errors,
            wait_for_other_updates=wait_for_other_updates)

    def _update(self, action, data=None, is_installation=False, timeout=900,
                max_errors=10, wait_for_other_updates=120):
        if data is None:
            data = {
                'version': None
            }
        if not wait_for_other_updates:
            wait_for_other_updates = 0

        if is_installation:
            uri = '/api/v2/updates/install/'
        else:
            uri = '/api/v2/updates/'

        start_time = time.time()
        while True:
            response = self.api_call('post', uri,
                                     data=json.dumps(data),
                                     raise_for_status=False)
            if response.status_code == 403 and \
                    'still in progress' in response.text and \
                    time.time() - start_time <= wait_for_other_updates:
                self.logger.info('Waiting for previous update to finish...')
                time.sleep(5)
                continue
            try:
                response.raise_for_status()
            except Exception:
                self._log_request_response(response, self.logger.error)
                raise
            break

        self.logger.info(u'Waiting for {}'.format(action))
        self.wait_for_smc(max_errors, timeout, action)

    def _get_uri_from_configuration(self, name):
        return self.api_call(
            'get', '/api/v2/configuration/').json()['results'][0][name]

    def is_apply_changes_needed(self):
        self.logger.info('Checking if apply changes is needed')
        return self.api_call(
            'get', self._get_uri_from_configuration('update_needed')
        ).json()['needed']

    def upload_file(self, path, dest_dirent, new_name=''):
        name = os.path.basename(path) if len(new_name) == 0 else new_name
        size = os.stat(path).st_size
        files = {'uploaded_file': (name, open(path, 'rb'),
                 'application/octet-stream')}
        uri_with_token = self.api_call('get', dest_dirent['upload']).json()
        dest_url = '{}&size={}'.format(uri_with_token, size)
        return self.api_call('post', dest_url, files=files)

    def download_file(self, src_dirent):
        r = self.api_call('get', src_dirent['download'], stream=True)

        fd, filename = tempfile.mkstemp()
        fp = os.fdopen(fd, 'wb+')
        fp.write(r.content)
        fp.close()

        return filename

    def make_folder(self, new_folder, dest_dirents):
        endpoint = '%s%s' % (dest_dirents['uri'], new_folder)
        return self.api_call('post', endpoint)

    def _post_action(self, src, src_paths, dst_drive, dst_path):
        if not isinstance(src_paths, list):
            src_paths = [src_paths]
        data = {
            'destination_drive': dst_drive,
            'destination_path': dst_path,
            'source_paths': src_paths,
        }
        action = self.api_call('post', src, data=json.dumps(data)).json()

        MAX_RETRIES = 60
        retries = 0
        while retries < MAX_RETRIES and action['status'] == 'PENDING':
            retries += 1
            action = self.api_call('get', action['uri']).json()
            time.sleep(0.25)

        if action['status'] != "SUCCESS":
            raise Exception(
                'Copy/Move action finished with %s status' % action['status'])

    def copy_file(self, src_drive, src_paths, dst_drive, dst_path='/'):
        return self._post_action(src_drive['copy'], src_paths,
                                 dst_drive['uri'], dst_path)

    def move_file(self, src_drive, src_paths, dst_drive, dst_path='/'):
        return self._post_action(src_drive['move'], src_paths,
                                 dst_drive['uri'], dst_path)

    def get_preview(self, dirent):
        uri = urlparse(
            unquote(urlparse(dirent['preview']).query.partition('=')[2]))
        path = [arg for arg in uri.query.split('&') if 'path=' in arg][0]
        content_uri = '%s://%s%s?%s' % (uri.scheme, uri.netloc, uri.path, path)
        generate_preview = self.api_call('post', content_uri).json()
        task = self.api_call('get', generate_preview['uri']).json()
        limit = datetime.now() + timedelta(minutes=2)
        while task['status'] == 'PENDING':
            time.sleep(1)
            task = self.api_call('get', generate_preview['uri']).json()
            if datetime.now() > limit:
                raise TimeoutError(
                    "The preview couldn't be downloaded on time")

        if task['status'] != 'SUCCESS':
            raise PreviewError(
                'The preview has finished with status %s' % task['status'])

        r = self.api_call('get', task['result'], stream=True)

        _, filename = tempfile.mkstemp()
        with open(filename, 'wb') as fp:
            fp.write(r.raw.read())

        return filename

    def download_share(self, share_api_object, public=True):
        content_url = u'{}://{}/api/shared_access/{}?download=true'.format(
            self.protocol, self.ip, share_api_object['guid'])
        if public:
            r = requests.get(content_url, stream=True)
        else:
            r = self.session.get(content_url, stream=True)

        data = r.raw.read(1024)
        all_data = data
        while data:
            data = r.raw.read(1024)
            all_data += data

        if share_api_object['mode'] == 'VIEW' and not \
           all_data.startswith('%PDF'):
            raise RuntimeError(
                'Raw content of PDF does not start with "%PDF"')

        _, filename = tempfile.mkstemp()
        with open(filename, 'wb') as fp:
            fp.write(all_data)

        return filename

    def download_logs(self, *args):
        args = None if len(args) != 1 else args[0]
        appliance = self.api_call(
            'get', '/api/v2/appliances/').json()['results'][0]
        actions = self.api_call('get', '/api/v2/actions').json()
        download_logs = [a for a in actions if a['name'] == 'download-logs'][0]
        payload = {
            'args_str': args,
            'appliances': [appliance['hostname']]
        }
        self.api_call('post', download_logs['uri'],
                      data=json.dumps(payload))
        dir_path = u'/logs/{}/'.format(appliance['hostname'])

        regex = 'href="([^"]*)"'
        filename = 'INPROGRESS'
        time.sleep(2)
        while 'INPROGRESS' in filename or filename == '../':
            r = self.api_call('get', dir_path)
            filename = re.findall(regex, r.text)[-1]
            time.sleep(1)

        r = self.api_call('get', dir_path + filename)

        tmp_dir = tempfile.mkdtemp()
        dst = os.path.join(tmp_dir, filename)
        with open(dst, 'wb+') as fp:
            for block in r.iter_content(1024):
                fp.write(block)

        return dst

    def get_user_rdp_gateway(self, user):
        task = self.api_call('get', user['get_rdp_gateway']).json()
        limit = datetime.now() + timedelta(minutes=2)

        while task['status'] == 'PENDING':
            time.sleep(1)
            task = self.api_call('get', task['uri']).json()
            if datetime.now() > limit:
                raise TimeoutError(
                    'RDP Gateaway of the user couldn\'t be fetched on time.')

        if task['status'] != 'SUCCESS':
            raise RdpGatewayError(
                'Error fetching the rdp gateway, status %s' % task['status'])

        return task['result']


class AwinguEasyHelper(AwinguHelper):
    logger = logging.getLogger('awingu_api_helpers')
    if 'hasHandlers' not in dir(logger) or not logger.hasHandlers():
        logger.setLevel(logging.DEBUG)
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        ch.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)s %(message)s'))
        logger.addHandler(ch)

    def __init__(self, ip):
        AwinguHelper.__init__(self, self.logger, requests.Session(), ip)
