#!/usr/bin/env python3
import logging
import os
import json
import base64


from shutil import copyfile
from install_awingu import AwinguInstaller
from configure_awingu import AwinguConfiguration

logger = logging.getLogger('deploy_awingu')
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler('deploy_awingu.log')
fh.setLevel(logging.DEBUG)
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)


def create_base_dn(domain_pieces):
    # eg 'dc=stack,dc=awingu,dc=com'
    base_dn = ''
    first = True

    for piece in domain_pieces:
        if first:
            first = False
            base_dn += 'dc=%s' % piece
        else:
            base_dn += ',dc=%s' % piece

    return base_dn


def create_global_config(configs_path, args):
    domain_pieces = args.domain.split('.')

    global_config = {
        'domains': {
            'name': args.netbios.upper(),
            'fqdn': args.domain,
            'bind_name': base64.decodebytes(
                args.domain_admin.encode()).decode(),
            'bind_password': base64.decodebytes(
                args.domain_pass.encode()).decode(),
            'dns': args.dns,
            'host_headers': [],
            'is_admin': True,
            'netbios': args.netbios.upper(),
            'server': args.dns,
            'base_dn': create_base_dn(domain_pieces),
            'create_bind_name': 'builtin.create_domain_bind_name',
            'find_groups': 'builtin.find_groups_by_member_of',
            'default_keyboard_layout': '0x409',
            'default_tours_enabled': True
        },
        'configuration': {
            'dns_ip': args.dns,
            'ntp_server': '0.europe.pool.ntp.org',
        }
    }

    ad_server_name = args.ad_server_name
    ad_host = '%s.%s' % (args.ad_server_name, args.domain)

    create_usergroups_config(configs_path)
    create_drives_config(configs_path, args)
    create_apps_config(configs_path, ad_server_name)
    create_appserver_config(configs_path, ad_server_name, ad_host)

    with open(os.path.join(configs_path, 'global.json'), 'w') as outfile:
        json.dump(global_config, outfile)


def create_usergroups_config(configs_path):
    usergroups_config = [{
        'name': 'Administrators',
        'is_admin': True,
        'is_sign_in_white_listed': True,
        'is_record': False,
        'is_staff': False,
    }]

    with open(os.path.join(configs_path, 'user-groups.json'), 'w') as outfile:
        json.dump(usergroups_config, outfile)


def create_drives_config(configs_path, args):
    ad_fqdn = '%s.%s' % (args.ad_server_name, args.domain)
    drives_config = [
        {
            'description': 'Home Drive via CIFS',
            'url': 'smb://%s/Users/<username>/documents' % ad_fqdn,
            'labels': [],
            'user_labels': ['all:'],
            'unc': '\\\\%s\\Users\\<username>\\documents\\<document>' %
                   args.ad_server_name,
            'use_domain': False,
            'backend': 'CIFS',
            'name': 'Home Drive (CIFS)',
            'config': []
        }
    ]

    with open(os.path.join(configs_path, 'drives.json'), 'w') as outfile:
        json.dump(drives_config, outfile)


def create_apps_config(configs_path, server_name):
    apps_config = [
        {
            'protocol': 'REMOTE-APP',
            'description': 'Notepad running on Application Server 2016',
            'server_labels': ['servergroup:win2016'],
            'labels': [],
            'working_folder': None,
            'user_labels': ['all:'],
            'command': 'NOTEPAD',
            'media_types': [
                'text/plain'
            ],
            'icon': 'notepad.png',
            'supports_unicode_kbd': True,
            'categories': [],
            'name': 'Notepad',
            'autostart_labels': [],
        },
        {
            'protocol': 'RDP',
            'description': 'AD Remote Desktop',
            'server_labels': ['servername:{}'.format(server_name)],
            'labels': [],
            'working_folder': None,
            'user_labels': ['admin:'],
            'command': 'C:\\Windows\\explorer.exe',
            'media_types': [],
            'icon': 'mstsc.png',
            'supports_unicode_kbd': True,
            'categories': [],
            'name': 'AD Remote desktop',
            'autostart_labels': [],
            'concurrent_usage': False,
        }
    ]

    with open(os.path.join(configs_path, 'apps.json'), 'w') as outfile:
        json.dump(apps_config, outfile)


def create_appserver_config(configs_path, server_name, server_host):
    appserver_config = [
        {
            'description': 'Active Directory Server',
            'labels': ['servername:{}'.format(server_name)],
            'enabled': True,
            'host': server_host,
            'max_connections': 1000,
            'port': 3389,
            'name': server_name
        }
    ]

    with open(os.path.join(configs_path, 'app-servers.json'), 'w') as outfile:
        json.dump(appserver_config, outfile)


def create_configs(args, config_fixtures='azure-arm'):
    base_path = os.path.dirname(os.path.realpath(__file__))
    configs_path = os.path.join(base_path, config_fixtures)

    if not os.path.exists(configs_path):
        os.makedirs(configs_path)

    create_global_config(configs_path, args)


def setup_icons():
    base_path = os.path.dirname(os.path.realpath(__file__))
    icons_path = ''.join([base_path, '/icons/'])

    if not os.path.exists(icons_path):
        os.makedirs(icons_path)

        copyfile('%s/notepad.png' % base_path, '%s/notepad.png' % icons_path)
        copyfile('%s/mstsc.png' % base_path, '%s/mstsc.png' % icons_path)


def setup(args):
    admin_pass = base64.decodebytes(args.admin_pass.encode()).decode()
    filedir = os.path.abspath(os.path.dirname(__file__))
    with open(os.path.join(filedir, 'config.json'), 'w+') as fp:
        json.dump({
            'username': 'awingu-admin',
            'password': admin_pass,
            'services': ['database', 'mq', 'memcache', 'frontend',
                         'worker', 'proxy', 'indexer', 'metering', 'rdpgw']
        }, fp)

    create_configs(args, config_fixtures='azure-arm')
    setup_icons()

    frontend_ip = '127.0.0.1'
    install_args = {
        'domain': 'azure-arm',
        'vm_name': 'awingu',
        'frontend_ip': frontend_ip,
        'repo_url': 'https://repo-pub.awingu.com',
        'skip_dev_keys': '',
        'domain_config_path': './',
        'install_timeout': str(60 * 45),
    }
    installer = AwinguInstaller(install_args)
    if not args.dry_run:
        installer.install_via_api()

    config_args = {
        'domains': 'azure-arm',
        'default_domain': 'azure-arm',
        'vm_name': 'awingu',
        'frontend_ip': frontend_ip,
        'invalidate_repo': 'no',
        # empty string makes it true,see configure_awingu script
        'import_appservers': '',
        'appserver_template': '''
            {
                "description": "description",
                "labels": ["servergroup:win2016"],
                "enabled": true,
                "host": "",
                "max_connections": 1000,
                "port": 3389,
                "name": ""
            }
        '''.replace(' ', '').replace('\n', ''),
        'import_appserver_blacklist':
            '%s.%s' % (args.ad_server_name.lower(), args.domain.lower()),
        'username': 'awingu-admin',
        'password': admin_pass
    }
    config_helper = AwinguConfiguration(config_args)
    if not args.dry_run:
        config_helper.configure_via_api()

    logger.info('Your Awingu environment is ready')
